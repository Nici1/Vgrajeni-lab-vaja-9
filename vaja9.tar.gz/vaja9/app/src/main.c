#include <asf.h>
#include <delay.h>
#include <test-more.h>
#include <ioport.h>
#include <lcd.h>
#include <adc.h>
#include <tc.h>
#include <dacc.h>
#include <uart.h>

#ifdef __cplusplus
extern "C" {
#endif
#define LED_L_PORT PIOB
#define LED_L_PIN PIO_PB27

#define L1_IDX PIO_PC26_IDX

int main (void)
{

    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/
    /*
        // led lucka
        ioport_init();
        ioport_enable_pin(L1_IDX);
        ioport_set_pin_dir(L1_IDX ,IOPORT_DIR_OUTPUT);
        ioport_set_pin_level(L1_IDX ,0);




        sysclk_enable_peripheral_clock(ID_TC0);
        tc_init(TC0, 0, TC_CMR_TCCLKS_TIMER_CLOCK3 | TC_CMR_WAVE);
        tc_start(TC0, 0);

    */
    /*sysclk_enable_peripheral_clock(ID_DACC);
    dacc_set_transfer_mode(DACC, DACC_MR_WORD_HALF);
    dacc_set_timing(DACC, 0x08, 0, 0x10);
    dacc_set_channel_selection(DACC, 1);
    dacc_enable_channel(DACC, 1);

    // init timer
    //systemcoreclock

    */
    /********************* Main loop     ***************************/

    //tc_write_rc(TC0, 0,uint32_t ul_value)


    //tc_stop(Tc *p_tc, uint32_t ul_channel)

    /*

        //uint32_t t=10;
        uint8_t duty = 25;
        //uint32_t t0,t1;
        uint32_t f = 2;
        //double f_on = f*0.01*duty;
        uint32_t n = SystemCoreClock/32/f;
        uint32_t n_on= n*duty/100;
        uint32_t n_off= n*(100-duty)/100;
        //to so procenti

        uint32_t n_zdaj, n_prej, n_delta;
        n_prej = tc_read_cv(TC0, 0);
        n_delta = n_off;

        while(1)
        {


        n_zdaj = tc_read_cv(TC0, 0);
        if(n_zdaj - n_prej > n_delta){
            if(n_delta == n_on){
                ioport_set_pin_level(L1_IDX ,0);
                n_delta=n_off;

                }

            else{
                ioport_set_pin_level(L1_IDX ,1);
                n_delta=n_on;

                }
                n_prej=n_zdaj;

            }

        }
    */

// ISR prekinitvena rutina
    /*
    uint_fast32_t n_on, n_off;
    bool led_status=0;
    int vrednost=0;
    */

//uint32_t n_time;

#define NS 10 /* število vzorcev */
//int sinus[NS]; /* tabela vzorcev sinusnega signala */
//int triang[NS]; /* tabela vzorcev trikotnega signala */



    //  NVIC_EnableIRQ(TC0_IRQn);
//   sysclk_enable_peripheral_clock(ID_TC0);
    //  tc_init(TC0, 0, TC_CMR_TCCLKS_TIMER_CLOCK3 | TC_CMR_WAVE | TC_CMR_WAVSEL_UP_RC);
    // tc_enable_interrupt(TC0, 0, TC_IER_Clcd_string[i]PCS);

    NVIC_EnableIRQ(UART_IRQn);

    sysclk_enable_peripheral_clock(ID_PIOA);
    pio_set_peripheral(PIOA, PIO_PERIPH_A, PIO_PA8A_URXD | PIO_PA9A_UTXD);
    pio_pull_up(PIOA, PIO_PA8A_URXD | PIO_PA9A_UTXD, PIO_PULLUP);
    sysclk_enable_peripheral_clock(ID_UART);

    sam_uart_opt_t uart_opts =
    {
        .ul_mck = SystemCoreClock, // master clock
        .ul_baudrate = 115200, // hitrost prenosa
        .ul_mode = UART_MR_CHMODE_NORMAL | UART_MR_PAR_NO // glej datasheet
    };

    uart_init(UART, &uart_opts);
    uart_reset(UART);
    uart_reset_status(UART);
    uart_enable_interrupt(UART, UART_IER_RXRDY);
    uart_enable(UART);
    lcd_init();




    while(1)
    {
        lcd_driver();
    }


    /*
        void TC0_Handler(void)
    {
        tc_get_status(TC0, 0);

        if ((dacc_get_interrupt_status(DACC) & DACC_ISR_TXRDY)==1){
            dacc_write_conversion_data(DACC, triang[vrednost]);
            vrednost++;
            if(vrednost==10){
                vrednost=0;
            }
            tc_write_rc(TC0, 0, n_on);
        }

    }


    */
    /******************** varnost     ***************************/
    while(1)
    {


    }

}
void UART_Handler(void)
{
    static int i=0;
    static bool ali_na_lcd=1;
    uint32_t status = uart_get_status(UART);
    uint8_t puc_data;
    uart_read(UART, &puc_data);

    if(status & (UART_SR_PARE |UART_SR_FRAME |UART_SR_OVRE)){
    //error
    //LED ON
    while(1){
    return;}
    }

    if(puc_data==27)
    {
        ali_na_lcd= !ali_na_lcd;
    }
    else if(ali_na_lcd)
    {

        if(puc_data ==127 && i>0)
        {
            i=i-1;
            lcd_string[i]=' ';
        }
        else if(puc_data ==127 && i==0)
        {
            i=31;
            lcd_string[i]=' ';

        }
        else
        {
            lcd_string[i] = (char)puc_data;
        }
        if(i==31 && puc_data != 127)
        {
            i=0;
        }
        else if (i!=31 && puc_data != 127)
        {
            i++;
        }


    }
    else if(!ali_na_lcd)
    {
        uart_write(UART, puc_data);

    }


}

#ifdef __cplusplus
}
#endif
