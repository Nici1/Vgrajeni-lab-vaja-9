#include <test-more.h>
#include <ioport.h>
#include <pio.h>
#include <asf.h>
#include <adc.h>




void adc_setup(void){
    sysclk_enable_peripheral_clock(ID_ADC);
    adc_init(ADC, 512, 6400000, ADC_STARTUP_TIME_4);
    adc_configure_timing(ADC, 0,ADC_SETTLING_TIME_3 ,1);
    adc_set_resolution(ADC, ADC_12_BITS );
    adc_configure_trigger(ADC, ADC_TRIG_SW,0);
    adc_enable_channel(ADC, ADC_CHANNEL_7);
}

uint32_t adc_read(void){


// sprozi ad pretvornik, pocaka na rezultat:
//1. DRDY bit v ISR -> adc_get_latest_value()
//2. E0C7 bit v ISR -> adc_get_CHANNEL_value()



 adc_start(ADC);

 uint32_t out=0;

    do{
    out=adc_get_status(ADC);}
    while( !(out & ADC_ISR_DRDY));

    return adc_get_latest_value(ADC);




}




